document.addEventListener("DOMContentLoaded", () => {
  console.log("App initialized");
});
